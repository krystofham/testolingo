from flask import Flask, render_template, request, url_for, redirect

app = Flask(__name__, template_folder="templates", static_folder="static")
streak_actual = 0
streak_high = 0
streak_before = 0
@app.route('/')
def home():
    return render_template('index.html')

@app.route('/nejim_testoviny')
def nejim_testoviny():
        # Reset streak
    global streak_actual
    streak_actual = 0
    return render_template('nejim_testoviny.html')

@app.route("/prehled")
def prehled():
    # Fetch streak information    
    return render_template('prehled.html', streak_actual=streak_actual, streak_before=streak_before,streak_high=streak_high)

@app.route('/submit', methods=['POST'])
def submit():
    global streak_actual
    global streak_before
    global streak_high
    odpoved = request.form.get('odpoved')
    password = request.form.get('password')  # heslo z formuláře
    if password == "3.1415926535_pi":
        if odpoved == "ano":
            streak_actual += 1
            if streak_high < streak_actual:
                streak_high = streak_actual
            streak_before = streak_actual 
            return redirect(url_for("prehled"))
        else:
            return redirect(url_for("nejim_testoviny"))
    else:
        return "Nesprávné heslo."

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
